# DockSlate 0.1.5

[Open the HTML guide](guide.html) | [Desktop executable](DockSlate.exe) | [Request status](docs/REQUEST_STATUS.md)

DockSlate 0.1.5 - Windows x64

1. Open guide.html for instructions and current verification limits.
2. DockSlate.exe is the desktop application. HTML files do not control WSL.
3. Requires Windows 11 x64, WSL 2.4.10+ and WebView2.
4. Extract the complete ZIP and keep DockSlate.exe, bin and libexec together.
5. bin\docker.exe is the launcher; libexec contains the official Windows CLI and plugins.

Unsigned development build. The reported security alert remains unresolved.
Do not disable protection or add an exception on this package's advice.
Deleting this folder does not unregister the WSL distribution or delete volumes.