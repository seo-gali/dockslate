# 사용자 요청 체크리스트

## 0.1.11 배포 준비

Docker Desktop 데이터 가져오기, 기존 Docker PATH 공존 검사와 systemd 준비 대기를 포함한다. [가져오기 검사](https://github.com/seo-gali/dockslate/blob/main/docs/results/desktop-migration.json)의 Node 16개·Rust 18개·실제 격리 볼륨 검사는 통과했다. 현재 앱·CLI·새 EXE·ZIP을 제작·검증 중이며 공개 파일은 아직 0.1.10이다. Docker Desktop과의 전체 이전, 전체 설치·제거·WSL 재부팅 검사는 미실행이다.

갱신: 2026-11-20 · 공개 배포본 **0.1.10 미서명 개발판**. 구현·실제 Windows 확인·전체 회귀를 구분한다. 정식 배포 점검 전체 완료를 의미하지 않는다.

| 현재 근거 | 확인 범위 |
| --- | --- |
| [0.1.10 보안 개발판 공개](https://github.com/seo-gali/dockslate/blob/main/docs/results/public-distribution-0.1.10.md) | 새 EXE·ZIP·고지·SHA256SUMS 공개 다운로드 대조. 실제 이벤트 18개·기존 컨테이너 5개 보존·트레이 종료 통과. 네 파일 해시의 VirusTotal 탐지 0, 시간 초과·미지원 구분. 인증서 미보유로 미서명 공개 명시 승인. 실제 설치/제거·WSL 재시작·롤백·정식 서명은 미실행 |
| [보안 점검과 수정](results/security-review-20261119.md) | CSP·디버그/입력·시크릿 검사·로컬 거부 로그·의존성 정기 검사 정의. Tokio·공식 Windows 도구 갱신. Node 14개·Rust 보안 10개·Windows 프로세스 7개·CLI 6개 통과. npm 0건, Cargo/Go 권고 12개 버전 남음. 기존 구조 개편 패키지에는 이 후속 수정이 미포함, 실제 설치·엔진·원격 CI는 미검증 |
| [구조 개편본 로컬 패키지](https://github.com/seo-gali/dockslate/blob/main/docs/results/refactor-packages-20261116.md) | 새 앱·CLI·설치 EXE·ZIP 제작 완료. ZIP 401개·공통 파일 397개·오프라인 CLI 4개 검증. 승인된 GitHub 포장 1회 성공 후 임시 브랜치·복사본 정리. 0.1.10·별도 로컬 폴더, 실제 설치·새 파일 백신 검사는 미실행 |
| [구조 개편·수정 검증](https://github.com/seo-gali/dockslate/blob/main/docs/results/architecture-refactor.md) | 시간 제한 수정·IPC 85개 계약·조회/전송 책임 분리·소스 CI 정의·공통 문서 동봉·독립 사이트 빌드. 로컬 공통 검사·Windows 프로세스 7개·격리 브라우저 10개 통과. 원격 CI·설치판 재제작·엔진 변경 E2E 미실행 |
| [전체 구조·테스트·문서 검토](https://github.com/seo-gali/dockslate/blob/main/docs/ARCHITECTURE_REVIEW.md) | 최초 감사에서 9개 문제를 확인하고 위 후속 수정을 적용. 불필요한 직접 의존성 0개. 중복 제품 범위 문서 제거·문서 맵 정정. 작업 상태 모델·추가 기능별 디렉터리 분리는 실제 요구 시 검토 |
| [설치 전 기존 버전 제거 오류](https://github.com/seo-gali/dockslate/blob/main/docs/results/installer-upgrade.md) | 누락된 설치 경로 등록 때문에 빈 `_?=`가 전달되는 실패 재현. 현재 PC의 기본값 하나 복구, 버전 독립 복원 hook 소스 수정·실제 MUI 검사 13개 통과. 새 설치판 재빌드·전체 제거/업그레이드 미실행 |
| [중복 생성물 정리](https://github.com/seo-gali/dockslate/blob/main/docs/results/generated-copy-cleanup.md) | 완료된 임시 프로필·설치본 복사본·전달 ZIP·포터블 압축 해제본·사이트 출력 28개 대상(약 2.10GB) 삭제. 원본·법적 고지·빌드 입력·실행용 CLI 보존 |
| [초기 0.1.10 제작·보류 기록](https://github.com/seo-gali/dockslate/blob/main/docs/results/release-0.1.10.md) | 앱·CLI·포터블 ZIP 622개 파일·설치 EXE 내부 대조, 실제 트레이 검사 15개 통과. 정확한 EXE의 Microsoft 탐지 1건으로 공개 배포 보류. ZIP 0/67. 오탐 미확정·Microsoft 검토 미제출. 공개판은 0.1.9 유지 |
| [0.1.9 제작](https://github.com/seo-gali/dockslate/blob/main/docs/results/release-0.1.9.md) | 설치 EXE·포터블 ZIP·고지 ZIP·SHA256SUMS 생성. 내부 앱·CLI·공식 구성 요소·문서 대조와 ZIP 615개 파일 검사 통과. 실제 설치·제거·공개 배포와 구분 |
| [0.1.10 트레이](https://github.com/seo-gali/dockslate/blob/main/docs/results/tray-background.md) | X로 트레이 숨김·복원, 열기·컨테이너·이미지·전체 새로고침·설정·완전 종료, 한영 메뉴. 격리 Windows 후보 검사. 공개 0.1.9에는 미포함 |
| [설치·제거 후반 대기](https://github.com/seo-gali/dockslate/blob/main/docs/results/installer-delay.md) | 0.1.9 설치판 반영: 알림 전체 2초 예산·등록 단계/경과 시간 표시. 실제 NSIS·지연 창 24개에서 두 경로 2,015ms, PATH 검사 9개 통과. 원래 지연 호출·실제 전체 제거는 미확정 |
| [공개 배포·무결성·검사](https://github.com/seo-gali/dockslate/blob/main/docs/results/public-distribution-0.1.9.md) | 0.1.9 GitHub Release 첨부 4개·SHA256SUMS 공개 다운로드 대조. VirusTotal EXE 0/64·ZIP 0/65. 홈페이지·정적 자산·공개 파일 및 과거 고지 URL 12개 대조 통과 |
| [0.1.8 제작](https://github.com/seo-gali/dockslate/blob/main/docs/results/release-0.1.8.md) · [자동 시작·컨테이너 일괄 작업](https://github.com/seo-gali/dockslate/blob/main/docs/results/startup-bulk-feedback.md) | 독립된 엔진·창 자동 시작, 표 체크박스·시작·중지·재시작. 실제 실행 검증·공개 배포는 제작·검사 결과와 구분. 공개 0.1.9에 포함 |
| [0.1.7 릴리스](https://github.com/seo-gali/dockslate/blob/main/docs/results/release-0.1.7.md) | 실제 앱 24개·CLI 4개, ZIP 604개 파일·설치 EXE 내부, 공개 다운로드 3개 및 사이트·과거 고지 경로 검증 |
| [0.1.6 릴리스](https://github.com/seo-gali/dockslate/blob/main/docs/results/release-0.1.6.md) | 앱·CLI 빌드, Rust·TypeScript, 읽기 전용 Windows 검사 10개·CLI 명령 4개, 설치 파일 내부·공개 다운로드 검증 |
| [실제 재설치](https://github.com/seo-gali/dockslate/blob/main/docs/results/reinstall-recovery.md) | 기존 데이터가 없는 이 PC의 잔여 등록 정리·새 엔진 설치 후 실제 설치 EXE 종료 0. CLI·커널 검사 14개·앱 화면 검사 5개. 기존 데이터 복원·제거·전체 회귀는 미검증 |
| [0.1.6 가이드 촬영](https://github.com/seo-gali/dockslate/blob/main/docs/results/guide-video.json) | 실제 이미지 검색·Pull·컨테이너 생성·HTTP, 상세·로그·파일·터미널, Dockerfile·단일 서비스 Compose 빌드·승인 실행. 실제 정리·압축은 실행하지 않음 |
| [WSL 커널](https://github.com/seo-gali/dockslate/blob/main/docs/results/cve-2026-98432-wsl.md) | 이 PC의 별도 호스트 수정·실행 커널 확인. 앱 설치 파일에 포함하지 않으며 다른 장비·DGX 검증과 구분 |
| [조회 구조·핫 패스 점검](https://github.com/seo-gali/dockslate/blob/main/docs/results/hot-path-review.md) | 전역 결과 캐시 제거·고정 배열·비트셋·독립 I/O 병렬화. 빈 엔진의 읽기 전용 비교와 검증 한계 |
| [0.1.6 재패키징](https://github.com/seo-gali/dockslate/blob/main/docs/results/repackage-0.1.6.md) | 최적화한 앱을 설치 EXE·ZIP에 반영. 네이티브 14개·CLI 4개, ZIP 전체 파일과 설치 EXE 내부 대조. 실제 설치·제거는 미실행 |
| [Docker 이벤트 자동 갱신](https://github.com/seo-gali/dockslate/blob/main/docs/results/engine-events.md) | 0.1.7 실제 Windows 검사 24개 통과. 외부 Compose·이름·이미지·볼륨·네트워크 변경과 연결 복구, DockSlate WSL 재시작·SQL 실행 상태 복원 |

현재 예제는 [Node.js 웹 앱](../examples/basic-web/README.md)이다. 파일 선택 직후 이미지 빌드가 시작되고 컨테이너 실행은 별도 동작이다. 사용 가이드 영상은 [YouTube](https://youtu.be/EbL7LkbNrPY)에서 제공하며 로컬 media 폴더는 Git에 포함하지 않는다.

아래 표의 기존 통과는 연결된 기록의 버전·시점에 해당한다. 과거 브라우저 화면이나 이전 EXE 검사로 최신 앱 전체 검증을 대신하지 않는다. **남음**은 해당 사용자 경로 미실행을 뜻한다. [프로덕션 배포 전 10개 점검](https://github.com/seo-gali/dockslate/blob/main/docs/results/production-readiness.md)의 미서명·접근 경고 원인·전체 회귀·데이터 복구 항목은 남아 있다.

## 화면 · 조작

| 요청 | 구현 | 실제 검증 |
| --- | --- | --- |
| 설명 축소·공간·탭 정리 | 반영 | 당시 일반 화면 확인. 데이터 팝업의 최종 간격은 남음 |
| 이름 클릭 → 중앙 팝업 | 반영 | 이전 EXE 통과 |
| 모든 상세 탭 같은 크기 | 반영 | 당시 EXE의 병합 후 6개 탭 크기 통과 |
| 로그·JSON 여백, 버튼 크기 | 반영 | 당시 6개 탭 실제 화면 확인. 로그 안쪽 여백 확인 |
| 한국어·영어, 상세 이름 번역 | 반영 | 당시 화면 전환·저장 통과. 엔진 원문·사용자 데이터는 보존 |
| 다크·라이트, 폰트 조절 | 반영, 11~16px·기본 12px | 당시 화면 전환·저장 통과 |
| 설정 블록을 탭으로 | 화면 / 런타임 / 엔진 연결 | 당시 화면 통과 |
| 컨테이너 작업 메뉴 | 시작·중지·재시작·브라우저·수정·삭제 | 0.1.1 실제 수정 팝업의 취소·승인·이름 변경·재생성 통과 |
| 표 열 조절·최소 너비 | 전체 표에 공용 조절·저장. 헤더·배지·작업 버튼 크기 반영, 시각 열 최소 190px | 0.1.1 실제 표·키보드 조절·최소 너비·resize 툴팁 제거 검사 통과 |
| 표 정렬·선택 필터 | 데이터 열 정렬, 상태·종류·정리 가능 여부 선택. 전체 조회 결과에 적용 후 페이지 분할 | 실제 숫자·날짜 정렬, 원래 순서 복원, 필터 선택·해제 통과. [기록](https://github.com/seo-gali/dockslate/blob/main/docs/results/table-controls-0.1.1.json) |
| 정리 승인·작업 진행 | 중복 경고 제거, 처리 건수·현재 대상·경과 시간. 전체량 미확인 작업은 불확정 진행 표시 | 임시 컨테이너 2개 실제 삭제에서 검사→대상→1/2→2/2 알림 확인. 기존 데이터·볼륨 유지 |
| 전체 태그·ID·시각 표시 | 이미지 목록 ID 유지, 컨테이너 목록의 ID는 상세에서 확인. 시각은 초까지 표시 | 당시 실제 표·상세 ID 표시 범위 대조 통과 |
| 개요 정보 | API·CPU·메모리·OS·커널·아키텍처·저장소·엔진 ID·데이터 경로 추가, 단위 각주 제거 | 실제 엔진 응답 대조 통과 |
| 시작 후 상태·아이콘 반영 | 실제 상태 재조회 | 당시 실행 중 서버 버튼 전환 E2E 남음 |
| 시작 후 바로 중지되는 문제 | hello-world 정상 종료 안내 | hello-world 종료 코드 0 기록 확인. 0.1.6 Node.js 서버는 생성·HTTP 200 확인. 모든 재시작 정책의 회귀는 미검증 |
| 통계·상세 병합 | 상세 탭에 포함 | 당시 실제 화면의 6개 탭과 리소스 영역 확인 |
| 창 열 때 단일 통계 측정 | 반영, 수동 다시 측정 | 이전 유휴 조회 없음, 당시 병합 화면 확인 |
| Inspect 조회 수명·실패 복구 | 숨김 응답 무효화, 성공한 revision만 완료 기록. 폐기한 응답은 재사용하지 않고 새 요청 | [이전 실제 Windows 검사 7개](https://github.com/seo-gali/dockslate/blob/main/docs/results/inspect-lifecycle.md)는 캐시 제거 전 기록. 최신 검사 스크립트의 새 요청 기대값은 수정했으나 실제 컨테이너 회귀는 남음 |
| 툴팁 정리·번역 | 표의 차단 사유는 본문에 표시, 작업 아이콘은 앱 스타일의 짧은 툴팁 | 한국어 사용량 안내·엔진 상태와 영어 전환 실제 확인 |
| 트리형 파일 탐색 | 왼쪽 트리·오른쪽 목록/미리보기 | 이전 EXE 실제 데이터 통과 |
| 빈 검색어·공백 처리 | 검색 9곳 정규화. Hub는 공용 호출 경계에서도 거절·입력 변경 시 결과 초기화 | 프런트엔드 경계 19개 통과. 당시 EXE의 실제 Hub 0건·초기화 E2E 남음 |

## 이미지 · 빌드 · 리소스

| 요청 | 구현 | 실제 검증 |
| --- | --- | --- |
| 이미지 참조 컨테이너 함께 삭제 | 별도 선택·대상 확인·승인. 중지/생성/dead만 허용, 볼륨 보존 | 격리 생성/중지 참조·승인 거절·참조 변경 차단 통과. 실행 중 참조 시나리오 남음 |
| Dockerfile 파일 선택 후 빌드 | Windows 선택창·부모 폴더 컨텍스트 | [0.1.6 실제 파일 선택·빌드 결과 확인](https://github.com/seo-gali/dockslate/blob/main/docs/results/guide-video.json). [이전 가져오기 검증](https://github.com/seo-gali/dockslate/blob/main/docs/results/file-import-native-e2e.json)은 당시 범위. 임의 사용자 프로젝트는 미검증 |
| Compose 파일 선택 후 자동 빌드 | 제한 검증·빌드·별도 실행 승인 | [0.1.6 단일 서비스 빌드·승인 실행·HTTP 확인](https://github.com/seo-gali/dockslate/blob/main/docs/results/guide-video.json). [이전 기본 가져오기·빌드·실행 5개](https://github.com/seo-gali/dockslate/blob/main/docs/results/compose-import-e2e.json)는 당시 범위. [볼륨 연결·Windows HTTP 접속·CLI 재생성 후 파일 유지·포트 해제 등 8개 통과](https://github.com/seo-gali/dockslate/blob/main/docs/results/compose-volume-port-e2e.json). 기존 리소스·볼륨 메타데이터 보존, 엔진 중지 복원. 67 B 테스트 볼륨·BusyBox 기반 이미지·빌드 캐시 보존. 실제 사용자 프로젝트·다중 서비스는 미검증 |
| 실제 DB 쓰기·조회·영속성 | 앱에서 별도 MongoDB Compose 빌드·승인 실행 | [Windows 클라이언트의 문서 쓰기·조회·갱신, journal 응답, CLI 재생성 후 동일 문서·포트 접속 등 8개 통과](https://github.com/seo-gali/dockslate/blob/main/docs/results/compose-mongodb-e2e.json). 기존 DB·볼륨 보존, 엔진 중지 복원. 테스트 DB 볼륨 2개(약 210 MB) 보존. 인증·TLS·마이그레이션은 미검증 |
| deployment.yaml 전체 빌드 여부 | Compose 내용이면 제한 가져오기, Kubernetes 형식은 미지원 | 사용자 실제 프로젝트 입력 미제공·미검증 |
| 실행 설정에서 새 볼륨 생성 | 생성 후 새 컨테이너에 선택 | 생성→연결→실행 E2E 남음 |
| 실행 설정에서 네트워크 생성 | bridge·internal 생성 후 선택 | 기존 화면·네트워크 작업 확인, 당시 실행 경로 남음 |
| 기존 컨테이너 수정·볼륨 연결 | 이름은 직접 변경. 포트·네트워크·볼륨은 파일 보존 이미지와 승인 후 재생성 | 실제 쓰기 파일·볼륨 데이터 유지, 새 포트 HTTP, 네트워크 교체·볼륨 추가·단일 사용 승인 통과. Compose·Swarm·고정 IP 등은 이름 변경만 지원 |
| 볼륨·이미지·네트워크의 참조 표시 | 이름·상태를 목록에 표시. 이미지 참조를 공용 스냅샷에서 한 번 묶어 재사용 | 실제 엔진 목록과 표 대조 통과. 행별 추가 요청 없음 |
| 실행 명령어 확인 팝업 | Docker(WSL) 기본 / PowerShell 7.3+ | 두 형식 구문 검사 통과. 복사 명령 실제 실행 남음 |
| 볼륨·네트워크 통합 메뉴 | Resources → Volumes / Networks | 당시 탭·상태 보존 통과 |
| 볼륨 작업 전체 | 생성·복제·참조·파일·tar 입출력·비우기·삭제 | 이전 EXE 11개 실제 경로 통과 |
| 네트워크 관리 | 참조·IPAM·생성·미사용 삭제 승인 | 기본/참조 삭제 차단·승인 토큰·지정 네트워크 삭제 통과 |
| 빌드 관리 | 진행·기록·빌더·기록 가져오기/내보내기 | 이전 6개 실제 경로 통과. 원격 TLS/SSH/Kubernetes 미지원 |

Compose 가져오기 제한: 1~16개 서비스, 프로젝트 내부 상대 컨텍스트·새 named volume·bridge. include/extends/env_file/치환/secrets/configs/bind/privileged/장치/외부 리소스는 차단한다.

## 성능

| 요청 | 변경 | 확인 범위 |
| --- | --- | --- |
| 불필요한 렌더링 감지·제거 | 첫 방문 마운트·페이지/행 memo·데이터별 구독, 이미지/정리/빌드 기록 50행, 로그 검색 memo | 전체 목록 DOM·반복 문자열 계산 제거. 전후 렌더 횟수·CPU 수치 미측정 |
| 지연 로딩 | 메뉴·번역·상세 탭·빌드 패널·파일 탐색기 스타일 분리 | 배포 브라우저 검사 10개 통과. 이번 진입 JS 278.6→268.9KB, Containers 55.7→26.4KB. 전체 JS 합계 감소 아님 |
| 조회 구조·캐시 제거 | 공용 조회의 고정 배열·개별 구독, 전역 로그/파일/Inspect·빌드 상세·런타임 결과 캐시 제거. 화면의 현재 데이터·진행 중 요청만 유지 | [최신 변경·검증 범위](https://github.com/seo-gali/dockslate/blob/main/docs/results/hot-path-review.md). 사용자 Docker 빌드 캐시는 삭제하지 않음 |
| 느린 쿼리·N+1 | 독립 엔진 조회·자원 검사 병렬화, 목록 참조 일괄 집계, 선택한 빌드 기록 파일만 읽기 | SQL DB 없음. 통계는 최대 4개 작업자·16개 프런트엔드 배치 유지. 빈 엔진 조회 비교와 실제 부하 미검증을 [점검 기록](https://github.com/seo-gali/dockslate/blob/main/docs/results/hot-path-review.md)에 구분 |
| 이미지·폰트·스크립트 | SVG·시스템 폰트·분할 JS | 외부 폰트·래스터 UI 이미지 없음. 배포 파일 크기 측정 |

[검색·API·성능 점검과 미검증 범위](https://github.com/seo-gali/dockslate/blob/main/docs/results/api-performance.md)

## 런타임 · 배포 · 보안

| 요청 | 상태 | 남은 일 |
| --- | --- | --- |
| Docker Desktop 없는 독립 사용 | 전용 WSL Moby 설치·시작·API·컨테이너·포트·mount 이전 실제 검증 통과 | 당시 EXE의 실제 조작·로그 검증도 통과 |
| Apple container·Davit 적용 검토 | macOS 엔진 교체 미적용. 화면 밀도·작업 중심 UI, WSL 파일 경계 검토 | I/O 성능 비교 측정 없음 |
| 삭제·재설치 시 WSL 처리 | 신규 런타임은 LocalAppData, 기존 등록은 소유권·경로 확인 후 재사용 | [빈 엔진 실제 재설치 완료](https://github.com/seo-gali/dockslate/blob/main/docs/results/reinstall-recovery.md). 기존 데이터 보존 업그레이드·제거 전체 E2E는 미검증. 고아 등록 정리는 승인한 이 PC에 한정 |
| 디스크 정리·압축 | 정확한 대상 정리, WSL 식별·승인·잠금 복구 | [네이티브 복구 검사 8개·승인 후 실제 VM 종료·원본 압축 성공](https://github.com/seo-gali/dockslate/blob/main/docs/results/wsl-compaction-recovery.md). 1 MiB 회수·엔진 재연결·기존 리소스 보존·중지 복원. [갱신한 설치판의 동일 앱·CLI·고지 파일 대조 완료](https://github.com/seo-gali/dockslate/blob/main/docs/results/installer-engine-integration.json). 관리자 GUI 압축 버튼 전체 경로·제거는 미검증. [0.1.6 빈 엔진 재설치](https://github.com/seo-gali/dockslate/blob/main/docs/results/reinstall-recovery.md)는 별도 확인 |
| 파일로 HTML 열기 | site/index는 웹 원본, site-dist/index는 사이트 출력, src/index는 앱 진입점. site/guide는 독립 사용 안내 | 새 경로의 사이트·안내 이동, 원본·사이트·앱의 안내서 3개와 키보드·390px 검사 8개 통과. HTML 저장·인쇄·다운로드 중계 제거 |
| EXE·ZIP 다운로드·코드 서명 | 사용자 요청으로 미서명 개발 빌드 다운로드 허용. 강제 서명 차단 제거, 해시 검증 유지 | 정식 서명 미완료, 접근 경고 원인 미확인. [상태](results/code-signing.md) |
| 설치 파일 | 설치 중 엔진 대상 자동 확인 → 승인 후 설치·시작 → Windows CLI·Compose·Buildx 자동 검증. 긴 PATH 처리는 .NET 레지스트리 API 사용 | 수정 후 PATH 임시 키 검사 8개 통과. 사용자 설치 완료·엔진 연결·`docker ps` 성공 확인. 전체 설치·제거 E2E와 로컬 NSIS 읽기 오류 원인은 미검증 |
| 보안 제품 경고 | 공개 설치판·설치 준비·제거 확인의 취소 경로 파일 접근 17,751건 확인. 개인 브라우저 프로필 접근 0건, 앱 전용 History·Cookies 생성/읽기/쓰기 확인. 신뢰·예외 등록 없음 | [실측 범위와 한계](https://github.com/seo-gali/dockslate/blob/main/docs/results/browsing-data-alert.md). 원래 경고 대상, 당시 앱 별도 추적, 설치 완료·앱 데이터 삭제·전체 제거는 미확인 |

## 당시 추가 요청

| 요청 | 반영·검증 |
| --- | --- |
| GitHub Pages 다운로드 페이지 | site-dist/ 전체 사이트를 Pages Actions로 게시하도록 구성, src/index로 앱 분리. 원격 전환·게시 승인 완료, 적용 전. 새 로컬 Chrome 검사 26개 통과. Sitemap·canonical·robots·404·다운로드 3개 해시와 과거 고지 URL 6개 확인. 이전 공개 SEO·다운로드 검사는 당시 원격 상태로 구분. [구성·결과](https://github.com/seo-gali/dockslate/blob/main/docs/PAGES.md) |
| 엔진 사용료·라이선스 고지 | 현재 목록은 588개 항목·원문 392개·소스 11개다. 아래 555개 항목·원문 362개 검사는 이전 배포 기록이다. EXE·포터블·고지 ZIP의 375개 파일 해시·목록·바이너리 일치, 손상 고지 차단 검사 통과. 이 패키지 검사는 설치·실행을 포함하지 않으며 미서명 상태다. [범위·검증](https://github.com/seo-gali/dockslate/blob/main/docs/results/license-delivery.json) |
| README·안내서 정리·캡처 | 공개 주소·실제 앱 캡처·구성도 제공. 안내서의 저장·인쇄·중계 버튼과 코드를 제거. 앱 빌드·실제 개발 서버·안내서 8개 검사 통과 |
| Google 소유권 파일·Sitemap | 소유권 파일 원문·공개 HTTP 200 일치 확인, 사이트 등록은 사용자 확인. Sitemap 제출은 사용자 직접 진행이며 실제 제출·색인 여부는 미확인 |
| Pull 진행·완료 팝업과 닫기 | 실제 고정 digest Pull·완료 UI 통과 |
| 실행 폼을 이미지 아래에 | 선택한 행 바로 아래 펼침, 실제 생성 통과 |
| 생성 후 목록만 이동 | 새 행 강조, 상세·로그 자동 팝업 없음 확인 |
| 표 구분선·너비 조절 | 전체 표에 공용 조절·최소 너비 적용. 0.1.1 실제 UI와 한영·글자 크기별 검사 통과. 이전 1000·1200·1480px 드래그·저장 검사는 당시 산출물의 기록 |
| 컨테이너 이미지 이름 | 공용 로컬 이미지 목록에서 저장소·태그와 전체 ID 표시. 이름 표시를 위한 행별 추가 요청 없음 |
| 정리 대상 날짜 | 이미지·빌드 캐시의 실제 생성 시각 표시. 실제 엔진의 18개 항목 대조 통과, 미제공·잘못된 날짜는 미확인 |
| DB 포트 브라우저 열기 수정 | Mongo URI 복사·DB 브라우저 메뉴와 백엔드 차단 통과 |
| 2초 로그 갱신 대신 감지 | 실제 follow·Tauri 이벤트·창 숨김 종료·전체 재조회0 확인 |
| Compass 접속 실패 원인 | PC32768 연결 열림,27017 닫힘 확인. 실제 Compass 로그인은 미실행 |
| Windows docker 명령 없음 | 공식 Windows CLI·Compose·Buildx 동봉, 빈 프로필 버전 4개 통과. 이전 통합 명령 34개 중 32개 성공·파일 복사 2개 접근 거부. 기존 리소스 보존·중지 복원 확인. 사용자가 설치 후 `docker ps` 성공 확인. 전체 CLI 재검증은 남음. [구성·검증 범위](https://github.com/seo-gali/dockslate/blob/main/docs/results/windows-cli-contract.md) |

[이전 확장 기능의 경로와 검증 범위](https://github.com/seo-gali/dockslate/blob/main/docs/results/interaction-workflows.md)

## 근거

- [현재 0.1.9 빌드·산출물](https://github.com/seo-gali/dockslate/blob/main/docs/results/release-0.1.9.md)
- [이전 프런트엔드·성능 검증](https://github.com/seo-gali/dockslate/blob/main/docs/results/refinement-verification.md)
- [이전 확장 기능 검증](https://github.com/seo-gali/dockslate/blob/main/docs/results/workbench-verification.md)
- [독립 엔진 검증](https://github.com/seo-gali/dockslate/blob/main/docs/results/standalone-runtime-verification.md)
- [보안 경고 조사](https://github.com/seo-gali/dockslate/blob/main/docs/results/browsing-data-alert.md)
- [현재 설치·앱·CLI 해시](https://github.com/seo-gali/dockslate/blob/main/docs/results/installer-engine-integration.json)
- [이전 EXE 해시](https://github.com/seo-gali/dockslate/blob/main/docs/results/refinement-build.json)
- [file://·다운로드 실제 검사](https://github.com/seo-gali/dockslate/blob/main/docs/results/guide-delivery-e2e.json)

실제 압축은 위에 기록한 동일 대상·검사 범위에서만 성공이다. 대규모 공간 회수·사용자 프로젝트 빌드·정식 배포 준비·악성 여부를 완료나 정상으로 표시하지 않는다. 새 가져오기 경로는 위에 연결한 격리 Compose·볼륨/포트·MongoDB 검사 범위에서만 통과다.
