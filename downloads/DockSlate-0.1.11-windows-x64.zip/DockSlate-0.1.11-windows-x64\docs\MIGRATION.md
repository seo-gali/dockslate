# Docker Desktop에서 가져오기

설정의 **데이터 가져오기**에서 실행 중인 Docker Desktop Linux 엔진을 조회하고 이미지·중지된 컨테이너·local 볼륨을 선택한다. DockSlate 엔진도 먼저 시작해야 한다. 0.1.11부터 제공하며 현재 배포를 준비 중이다.

## 복사와 보존

- 검사 → 대상·영향 확인 → 승인 → 복사 순서다. 선택한 컨테이너의 이미지·볼륨·bridge 네트워크도 함께 검사한다. 이름·태그 충돌은 덮어쓰지 않고 차단한다.
- 원본 컨테이너를 자동으로 중지하거나 삭제하지 않는다. 볼륨을 사용하는 컨테이너가 하나라도 실행 중이면 복사를 차단한다. 이전 중에는 Docker Desktop에서 원본을 변경하지 않는다.
- 이미지와 컨테이너 쓰기 계층, 환경 설정, 포트, 볼륨 연결을 복사한다. 컨테이너 쓰기 계층은 export/import로 보존하므로 복사본 이미지의 원래 레이어 이력은 유지되지 않는다. 환경 변수에 든 비밀번호도 새 컨테이너로 전달되며 화면·진행 로그에는 값을 표시하지 않는다.
- 볼륨은 실행하지 않는 임시 컨테이너에 연결해 tar 스트림으로 복사한다. 원본 볼륨은 읽기 전용·nocopy다. 임시 컨테이너만 정리하며 원본 볼륨·컨테이너·이미지는 제거하지 않는다. 새 이미지를 외부에서 받거나 데이터를 외부로 전송하지 않는다.
- 가져온 컨테이너는 중지 상태로 둔다. 데이터·설정을 확인하고 Docker Desktop 쪽 서비스를 멈춘 상태에서 직접 시작한다. 원래 재시작 정책은 복사하므로 이후 엔진 재시작 때 실행될 수 있다.
- 중간 실패 시 이미 복사한 대상은 남겨 결과에 표시한다. 재실행으로 덮어쓰거나 일괄 롤백하지 않는다. tar는 공용 임시 폴더 대신 `%LOCALAPPDATA%\DockSlate\migration` 아래에 만들고 성공·실패 시 닫고 삭제한다. 파일당 64 GiB·복사당 1시간까지 지원하며 앱·PC의 강제 종료 후 남은 파일은 자동 삭제하지 않는다.

## 범위

Linux 컨테이너, 일반 bridge/none 네트워크, 옵션 없는 local 볼륨을 지원한다. Windows·WSL bind, 특권·장치·host/container 네트워크·고정 IP·Swarm 설정은 자동 이전하지 않고 사유를 표시한다. Compose 프로젝트 파일·Docker 로그인 정보·Kubernetes·빌드 캐시·로그·메모리·tmpfs 내용은 복사하지 않는다. Compose 라벨은 유지하지만 기존 프로젝트를 편집·재배포하는 기능은 아니다.

Docker Desktop 제거는 별도 사용자 작업이다. 모든 복사본의 정상 동작과 데이터를 확인하기 전에는 제거하지 않는다. [Docker 제거 안내](https://docs.docker.com/desktop/uninstall/)는 제거 시 기존 데이터를 잃을 수 있음을 설명한다. [export](https://docs.docker.com/reference/cli/docker/container/export/)는 볼륨 데이터를 포함하지 않으므로 볼륨을 별도로 복사하며, [cp](https://docs.docker.com/reference/cli/docker/container/cp/)의 tar 스트림·archive 모드로 UID/GID를 전달한다.

## 검증 기준

원본·대상 엔진 ID 구분, 승인 만료·변경 후 재검사, 이름·태그 충돌, 실행 중 볼륨 참조, 미지원 설정 거절, 환경 변수 비노출, 큰 tar의 파일 스트리밍, 임시 컨테이너 정리, 실패 후 부분 결과를 검사한다. fixture 검사와 실제 Docker Desktop 데이터 이전 검사는 구분한다. 사용자 데이터의 이전·삭제는 개발 검증에 포함하지 않는다.

[현재 검사 기록](https://github.com/seo-gali/dockslate/blob/main/docs/results/desktop-migration.json): Node 16개·Rust 18개·PATH 11개·Windows 프로세스 7개와 한국어·영어 화면을 검사했다. 승인된 소유 엔진에서 임시 볼륨 2개·실행하지 않는 컨테이너 3개로 바이너리 내용·UID/GID·권한 왕복 복사, 읽기 전용 쓰기 거절, 익명 볼륨 미생성을 확인하고 정리했다. 기존 목록·상태는 복원됐다. 이 PC에는 Docker Desktop이 없어 실제 두 엔진 사이의 전체 이전과 새 설치판은 미검증이다.
