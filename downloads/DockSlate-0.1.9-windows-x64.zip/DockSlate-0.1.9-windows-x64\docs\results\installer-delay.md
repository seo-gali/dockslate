# 설치·제거 마지막 단계 지연

2026-11-06. 사용자 화면의 마지막 항목은 `dockslate-user-path.ps1` 압축 해제다. 이 위치는 앱 파일 삭제 후 PATH·자동 시작 등록을 정리하는 hook 안에 있다. 재확인 당시 실제 DockSlate 설치·제거 프로세스는 종료돼 있어 원래 지연 시간과 대기 호출을 직접 확정할 수 없다.

현재 hook은 등록 보조 PowerShell이 끝난 뒤 모든 최상위 창에 환경 변경을 알리고 창마다 최대 5초를 기다린다. [Microsoft 설명](https://learn.microsoft.com/en-us/windows/win32/api/winuser/nf-winuser-sendmessagetimeoutw)대로 이는 전체 5초 제한이 아니며 수신 창 수에 따라 길어질 수 있다. PowerShell 실행도 별도 대기 구간이므로 두 단계의 진행·소요 시간을 구분한다.

## 수정·확인 범위

설치·제거의 환경 변경 알림을 공유 함수로 모으고, Explorer에 먼저 알린 뒤 나머지 창은 짧게 기다리며 전체 대기 예산을 제한한다. 응답이 느린 창 때문에 등록 완료가 계속 지연되지 않게 한다. 등록 처리 시작·결과·경과 시간과 알림 단계를 로그에 표시한다. 기존 PATH 원문·형식·소유권 검사와 WSL·컨테이너·볼륨 보존은 유지한다.

실제 설치·제거를 다시 실행하지 않고, 기존 PATH 검증 및 동일한 NSIS 알림 함수를 사용하는 Windows 격리 검증으로 확인한다. 실제 결과를 기록하기 전에는 지연 해소나 배포 반영을 완료로 표시하지 않는다. 현재 배포 EXE는 교체하지 않는다.

## 실제 확인 결과

- `powershell -NoProfile -File scripts/verify-installer-environment.ps1`: 종료 0. 실제 NSIS 컴파일 함수와 서로 다른 스레드의 숨김 시험 창 24개를 사용했다. 각 창은 알림 처리에 5초를 사용한다. 기존 단일 창 대기는 5,000ms, 수정한 설치·제거 경로는 각각 2,015ms였다. NSIS 호출자 레지스터와 실제 PATH 원문·형식을 유지했다. [원본 SHA와 측정값](installer-delay.json).
- `powershell -NoProfile -File scripts/verify-installer-path.ps1`: 종료 0, 검사 9개 통과. 긴 PATH·중복·기존 소유권·등록 형식과 다른 자동 시작 명령 보존을 확인했다. 실제 사용자·시스템 PATH 변경 없음.
- `git diff --check`: 종료 0. 실제 설치·제거, 엔진 재시작, 설치 EXE 재생성·게시·Git push는 수행하지 않았다.
- 전체 설치 템플릿 전처리는 로컬 `nsis_tauri_utils::SemverCompare` 플러그인 인식 실패로 종료 1이었다. 전체 패키징 통과로 합산하지 않는다.

알림 대기 예산은 2,000ms다. Explorer를 먼저 최대 750ms 기다리고 나머지 창은 각각 최대 100ms, 남은 예산 안에서 처리한다. 응답이 늦거나 예산 뒤에 남은 창의 알림은 완료를 보장하지 않으며 필요하면 해당 앱을 다시 열어야 한다. 이 제한은 환경 변경 알림 단계에만 적용한다. 파일 삭제·PowerShell 시작 시간이 모두 2초로 제한된다는 의미가 아니다.

등록 보조 PowerShell의 호출과 소유권·형식 검사, 30초 출력 대기 설정은 유지했다. 이 설정은 [nsExec 문서](https://nsis.sourceforge.io/NsExec_plug-in)상 전체 실행 제한이 아니라 출력이 없을 때의 대기 시간이다. 진행 메시지와 실제 경과 시간을 추가했으며, 원래 화면이 이 호출에서 오래 머물렀는지는 당시 추적이 없어 미확정이다.
