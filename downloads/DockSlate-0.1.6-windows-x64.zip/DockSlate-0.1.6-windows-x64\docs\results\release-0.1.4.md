# 0.1.4 개발판 검증

0.1.4 Windows 앱 검사 10개와 설치 파일 내부 검증을 완료했다. 실제 설치·제거 실행과 전체 회귀 검사는 별도 미검증이다.

## 변경과 실제 확인

- Dockerfile 선택 후 자동 빌드, `다시 빌드`, 진행 중인 빌드에서 로그로 이동을 실제 확인했다. 파일 선택 시 자동 빌드하는 기존 동작은 유지한다.
- Dockerfile·Compose의 `파일 선택 닫기`를 오른쪽 아래에 맞췄다. 닫으면 선택과 이전 결과를 지우고 엔진의 이미지·빌드 기록은 유지한다.
- 가져온 Compose 프로젝트는 짧은 표시명을 사용하고 펼침 영역에서 전체 내부 이름을 확인한다. 실제 프로젝트 이름·충돌 검사·소유권 검사는 변경하지 않았다.
- `진행 중인 빌드`·`빌더 관리`로 메뉴를 구체화했다. 실제 진행 중인 앱 빌드만 표시하며, 빌더 관리에는 다음 빌드 환경을 고르는 목적을 표시한다.
- 컨테이너의 Compose 그룹은 마우스와 Enter로 접고 펼칠 수 있다. 일반 프로젝트 이름은 그대로 표시한다. Dockerfile 컨테이너는 Compose 그룹 대신 단독 컨테이너에 속한다.
- 정리 표의 헤더 체크박스는 검색·필터에 맞는 선택 가능 항목만 선택한다. 일부 선택 표시, 필터 밖 선택 유지, 차단 항목만 있는 경우 비활성화를 실제 확인했다. 페이지 분할 전에 선택 범위를 계산한다.
- 공통 확인창 최대 너비는 1040px, 최대 높이는 680px이며 작은 창에서는 여백을 제외한 크기로 줄어든다. 이미지 삭제 대상은 가로 카드로 배치하고 내용만 내부 스크롤한다. 이미지 참조 검사 완료 후 1668×900·1000×640에서 승인 영역과 하단 버튼이 창 안에 있는 것을 확인했다.

[실제 Windows 앱 검사 10개](ui-workflow-0.1.4.json). 앱 SHA-256: `7AD08317387307F4F50B15655DF02E3AC39FDBB272B181D632BB2691C41E01E2`.

## 검증 명령

| 명령 | 실제 결과 |
| --- | --- |
| `powershell -NoProfile -File scripts/desktop.ps1 -Mode build` | 일반 사용자 환경 종료 0. 첫 샌드박스 시도는 기존 EXE 교체 접근 거부로 종료 1 |
| `powershell -NoProfile -File scripts/build-cli.ps1` | 종료 0, CLI SHA-256 `0D8D95C523EDEE39D565E66995185A26C44177B5470405CE73BE600DF6A7E949` |
| `cargo check --manifest-path src-tauri/Cargo.toml --locked --offline` | 로컬 Rust 환경에서 종료 0 |
| `node scripts/verify-ui-workflow.mjs` | 종료 0, 실제 앱 검사 10개. 같은 EXE·격리 리소스에서 자동화 입력·대기 조건을 수정한 뒤 검증을 재개함 |
| Docker·debug·Compose·Buildx 버전 명령 4개 | 일반 사용자 환경 종료 0. 샌드박스에서는 런타임 메타데이터 접근 거부 |
| `node scripts/verify-license-inventory.mjs` | 종료 0, 구성 요소 555·고지 362·소스 11, 누락 0 |
| `git diff --check`·의존성 그래프 대조 | 종료 0. lock 변경은 앱 루트 버전뿐이며 의존성 그래프는 동일 |

재현 시 격리된 네이티브 앱 세션과 `scripts/prepare-ui-workflow.mjs`가 만든 표식·기존 리소스 목록이 필요하다. `scripts/cleanup-ui-workflow.mjs`는 표식·정확한 ID·생성 상태·볼륨 없음과 기존 목록을 대조한다. scratch 이미지와 실행하지 않은 컨테이너만 사용하며 DB·볼륨·새 네트워크·Prune은 검증 대상에서 제외한다.

검증 후 이 실행에서 생성한 컨테이너 2개와 이미지 3개만 제거했다. 기존 컨테이너 ID·이름·상태, 볼륨 8개의 이름과 네트워크 ID가 검사 전과 같았다. 테스트 앱은 정상 종료했다. 빌드 캐시는 Prune하지 않았다.

## 설치 파일 상태

`powershell -NoProfile -File scripts/build-installer.ps1 -SkipBuild`를 일반 사용자 환경에서 실행했으나 종료 1이다. NSIS가 `src-tauri/installer/user-path.ps1`을 열지 못해 설치 파일 생성이 중단됐다. 파일명 변경·보안 설정 변경·우회는 하지 않았다. 이후 사용자가 승인한 [GitHub 설치 빌드 1회](https://github.com/seo-gali/dockslate/actions/runs/41076346431)가 성공했다. 입력 커밋 `0f3bfd2df81e8f4b225abbdb7fa9930a130f79bb`의 ZIP에서 검증된 앱·CLI를 복원해 재컴파일 없이 묶었다. GitHub 산출물 12987591102의 크기·다이제스트와 실제 다운로드가 일치한다. 설치 파일을 실행하지 않고 앱·CLI 해시, 고지·소스 375개·인덱스·공식 구성 파일 8개·예제 5개·문서 8개·PATH 도우미를 대조했다. 임시 workflow는 삭제했다.

이미지 삭제 확인은 기존 Mongo 이미지를 포함한 미리보기를 취소했으며 삭제를 실행하지 않았다. 처리 중 진행 표시의 새 배치, 새 설치·제거, 전체 회귀와 DB 동작은 이번 검증에 포함하지 않았다. HTML 안내서 브라우저 검사는 디버깅 세션 부재로 시간 초과했으며 통과로 계산하지 않는다. 설치판 서명과 기존 보안 경고는 미해결이다.

## 로컬 포터블 패키지

`powershell -NoProfile -File scripts/package-local.ps1` 종료 0이다. ZIP 내부 574개 파일을 로컬 출력 폴더와 SHA-256 대조했고, 고지 ZIP 378개 파일도 원본과 대조했다. 새 설치 EXE와 함께 다운로드를 0.1.4로 갱신한다. ZIP 내부 문서는 생성 시점의 기록이고, 최종 외부 해시·게시 상태는 저장소에서 별도로 관리한다.

| 파일 | 크기 | SHA-256 |
| --- | --- | --- |
| `DockSlate_0.1.4_x64-setup.exe` | 49255844B | `F26131F78385266DEA0D154E2C8FD6D174F7F2F4CCB6AE9920A949BF9A52D902` |
| `DockSlate-0.1.4-windows-x64.zip` | 63274826B | `B2F15BCB3EED05CFDE51090DE41F331FF3F3D0C3D6AA7B67A63EE939921CDFF5` |
| `DockSlate-0.1.4-third-party-licenses.zip` | 5161430B | `297E60F066AB10467010E296FD47DD4B7C7CFC81C9067D3335BC2F189F98AAF1` |

설치판·포터블·고지 ZIP의 고지 표지에는 0.1.3이 남아 있다. 의존성 구성은 동일하다. 포함된 기존 URL을 보존하기 위해 0.1.3 고지 ZIP은 유지하고 구버전 앱 설치 EXE·포터블 ZIP만 삭제한다. 공개 고지 페이지는 0.1.4로 갱신했다. 이 차이를 숨기거나 패키징 스냅샷을 사후 수정하지 않는다.

공개용 정적 사이트 생성 명령 `npm run build:site -- --publish` 종료 0이며 새 파일 3개와 루트·docs 사본의 해시를 확인했다. 구버전 EXE·포터블 ZIP 네 사본과 원본 대조를 마친 포터블 파일을 삭제했다. 구버전 빈 루트 폴더는 다른 프로세스의 디렉터리 잠금 때문에 남았으며 강제로 프로세스를 종료하지 않았다. 설치 산출물의 임시 다운로드·추출 사본 260,579,810B도 제거했다.

## 공개 다운로드 확인

[Pages 배포 41078098363](https://github.com/seo-gali/dockslate/actions/runs/41078098363) 성공 후 [실제 공개 파일 검사](public-release-0.1.4.json)를 수행했다. 루트 HTML이 생성한 사이트와 일치했고, 새 설치 EXE·포터블 ZIP·고지 ZIP 3개는 HTTP 200·크기·SHA-256이 모두 일치했다. 제거한 0.1.3 앱 EXE·ZIP 네 URL은 404이며 유지한 0.1.3 고지 ZIP 두 URL은 200·원본 해시와 일치한다. 임시 workflow는 추적 파일과 작업 트리에 없다. 설치 workflow는 입력 커밋에서 정확히 한 번, 재시도 없이 성공했다.
