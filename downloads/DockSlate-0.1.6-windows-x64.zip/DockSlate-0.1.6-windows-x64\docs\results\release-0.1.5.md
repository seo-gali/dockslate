# 0.1.5 개발판 검증

2026-10-31. 정리 실패 상세·재조회, 부모·공유 캐시 차단, 단일 Dockerfile/Compose 빌드 패널과 WSL 화면 하단 여백을 수정했다. [기능 검증](cleanup-feedback.md)은 기능 커밋 `3c40c49`의 Windows 검사 12개·실제 알림 컴포넌트 렌더링 2개다. 이후 앱 루트 버전만 0.1.5로 변경했으며 의존성 그래프와 엔진 구성은 동일하다. 새 바이너리의 PE·엔진 응답 버전 0.1.5, 읽기 전용 화면 검사 4개·CLI 명령 4개·앱/CLI 빌드·locked/offline Rust 검사 종료 0을 확인했다. 실제 부분 실패 삭제를 강제로 재현하지 않았다.

승인된 [GitHub 설치 빌드 1회](https://github.com/seo-gali/dockslate/actions/runs/41172785348)가 성공했다. 입력 커밋 `81e7711d85dea961f5f3ee20dec1f5d14853d97a`의 검증된 ZIP에서 앱·CLI를 재컴파일 없이 복원했다. GitHub artifact 13031389508의 크기·SHA-256 다이제스트가 실제 다운로드와 일치한다. 설치 파일을 실행하지 않고 앱·CLI 해시, 고지·소스 375개·인덱스, 공식 구성 파일 8개·예제 5개·문서 11개·PATH 도우미를 대조했다. 임시 workflow는 삭제했다.

포터블 ZIP 579개와 고지 ZIP 378개 파일을 원본과 대조했다. 새 패키지의 고지 표지·현행 ZIP 링크는 0.1.5다. 이전 설치판 문서에 포함된 0.1.3·0.1.4 고지 ZIP URL은 보존한다. 패키지 문서는 각 생성/입력 시점 스냅샷이며 최종 게시 증거는 저장소에서 관리한다.

| 파일 | 크기 | SHA-256 |
| --- | --- | --- |
| `DockSlate_0.1.5_x64-setup.exe` | 49260305B | `A9B1FF5ED188F7311BD7A764563AFEB8671C27CE1B3BFFCC6E2505DBB5284D46` |
| `DockSlate-0.1.5-windows-x64.zip` | 63289315B | `5BF378F6AC284F686553B8F556BA7E6D401B0DA00555EEFFEE1EE164383FA52F` |
| `DockSlate-0.1.5-third-party-licenses.zip` | 5161525B | `D427BA1E60254372E5C4F7F7A4862A86139C838943426C98CD160929268807D4` |

**커널 보안 패치를 포함한 릴리스가 아니다.** [CVE-2026-98432 조사](cve-2026-98432-wsl.md)의 미패치 위험을 유지한다. WSL·Ubuntu·Docker 업데이트와 전체 WSL 종료는 실행하지 않았다. 실제 설치·제거, 전체 회귀, 공격 재현, 코드 서명·기존 보안 경고 해소는 미검증이다.

새 다운로드의 root/docs 사본 크기·해시를 대조한 뒤 0.1.4 설치 EXE·ZIP 4개와 원본 ZIP의 모든 파일이 일치한 구버전 포터블 폴더를 제거했다. 사용자 편집 파일·다른 배포판·볼륨은 삭제하지 않았다. 사이트 생성 명령 `npm run build:site -- --publish`는 종료 0, 다운로드 3개 검증이다. [공개 URL 대조](public-release-0.1.5.json)도 완료했다.

[Pages 배포](https://github.com/seo-gali/dockslate/actions/runs/41173152173)가 게시 커밋 `1ad9e4bc58755070a23e489eb5db5a769a21dc69`에서 성공했다. 공개 EXE·포터블·고지 ZIP 3개는 HTTP 200·크기·SHA-256이 일치한다. 이전 앱 EXE·ZIP의 root/docs URL 4개는 404이며, 0.1.3·0.1.4 고지 URL 4개는 기존 해시로 200이다. 루트 HTML도 현재 생성본과 일치한다. 검증용 다운로드·설치판 추출 사본 260600508B를 제거하고 실제 배포물·검사 기록은 보존했다.
