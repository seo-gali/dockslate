# 구현과 검증 상태

동작·기본값·제한은 현재 코드가 기준이다. 소스 구현, 공개 파일에 포함된 기능, 실제 실행 결과를 구분한다. 문서를 고쳤다고 과거 EXE나 검사 결과가 바뀌지는 않는다.

## 현재 소스

| 영역 | 구현 범위와 근거 |
| --- | --- |
| 엔진 | 전용 WSL 2 Moby 설치·시작·중지, 실제 경로·소유권·엔진 ID 확인. 앱 실행 시 엔진 시작은 기본 활성화하며 사용자가 해제할 수 있다. Windows 로그인 시 엔진·앱 시작은 각각 선택한다. `src/runtime.tsx`, `src/startup.tsx`, `src-tauri/src/runtime.rs`, `startup.rs` |
| 컨테이너 | 개별·최대 256개 일괄 시작·중지·재시작, 자동 시작 정책, 상세·로그·터미널·파일·설정 수정. 삭제 선택은 최대 100개다. `src/pages/Containers.tsx`, `src-tauri/src/docker.rs`, `container_edit.rs` |
| Compose 프로젝트 | 프로젝트 버튼은 현재 페이지·검색 결과에 한정하지 않고 전체 구성원을 처리한다. 시작은 의존 순서, 중지는 역순, 재시작은 역순 중지 후 순서대로 시작한다. 명시된 healthcheck·성공 종료 조건을 확인하고 선행 실패 뒤 후속 작업을 중단한다. `docker.rs`의 `container_project_action` |
| 작업 대기 | 컨테이너 작업은 행별로 실행·대기를 표시하고 서로 다른 대상은 화면의 대기열에 추가해 순서대로 처리한다. 조회·검색·선택을 유지하며, 수정·삭제 같은 충돌 작업은 별도로 차단한다. 백엔드의 공통 변경 잠금과 상태·승인 검사는 유지한다. `src/container-action-queue.ts`, `src-tauri/src/main.rs` |
| 이미지·파일 빌드 | Hub 검색·Pull·로컬 이미지 실행, Dockerfile 빌드, 최대 16개 서비스의 제한된 Compose 검사·빌드·별도 승인 실행. `src/ComposeImport.tsx`, `src-tauri/src/compose.rs`, `image_build.rs` |
| Docker Desktop 데이터 복사 | 프로젝트·전체·개별 선택, 원본 정상 중지, 이미지·쓰기 계층·볼륨·bind 파일/폴더 복사와 선택한 실행 상태 복원. 완료 대상은 실제 대상과 완료 기록이 일치하면 목록에서 숨긴다. `src/MigrationPanel.tsx`, `src-tauri/src/migration.rs` |
| Compose 설정 가져오기 | 선택한 컨테이너 최대 16개의 실행 설정을 메모리 안에서 Compose 구성으로 변환하고 기존 검사·실행 승인을 사용한다. 원본 데이터·이미지는 복사하지 않으며 같은 이미지 ID가 대상에 필요하다. 볼륨은 새 빈 볼륨으로 만들고 공유 관계를 유지한다. bind·특권·미지원 옵션·빠진 의존 서비스는 차단한다. `src/MigrationComposePanel.tsx`, `src-tauri/src/migration/configuration.rs` |
| 리소스·디스크 | 볼륨·네트워크 관리, 미사용 이미지·빌드 캐시 선택 정리, 조건을 만족하는 WSL 공간 회수. 실행 중 컨테이너·참조 중 리소스는 삭제하지 않는다. `resources.rs`, `volumes.rs`, `wsl.rs` |
| 이벤트·트레이 | Docker 이벤트로 외부 변경을 반영한다. 창 닫기는 트레이 숨김이며 완전 종료는 트레이 메뉴에서 수행한다. `src/queries.ts`, `src-tauri/src/engine_events.rs`, `tray.rs` |

자세한 사용 절차는 [사용 안내](USER_GUIDE.md), 두 가지 이전 방식의 차이와 제한은 [데이터 가져오기](MIGRATION.md)에 있다.

## 시간 초과와 연결 수정

프로젝트의 의존 서비스 건강 상태 대기는 healthcheck의 시작 유예·간격·제한 시간·재시도 수를 반영해 2~30분으로 정한다. 성공 종료 조건은 최대 30분 기다리며 일반 API 응답 제한과 구분한다.

컨테이너 시작·중지·재시작 POST는 일반 조회와 분리해 120초를 사용한다. 데이터 이전의 원본 조회와 대상 inspect는 각각 120초이며, 대상 inspect는 Windows CLI 프록시를 다시 거치지 않고 소유 엔진 API를 직접 사용한다. 임시·대상 컨테이너 생성도 120초다. inspect 읽기 묶음은 최대 16개이며, 시간 초과된 읽기만 나눠 다시 처리한다. 생성·복사·시작 명령은 자동 재시도하지 않는다.

Docker Desktop 명령 실패는 종료 코드와 이미지 없음·마운트 거부·공간 부족·권한·연결 등 확인 가능한 고정 분류를 표시한다. 환경 값이 섞일 수 있는 원본 daemon 출력은 표시하지 않는다. 알 수 없는 원인은 실제 엔진 로그로 확인해야 한다.

이벤트 연결은 `Connection: close` 응답에서 소켓 참조가 사라지는 예외를 수정했다. 접속·헤더의 제한과 연결 이후 유휴 대기를 구분한다. 목록 조회·검사·Compose 구성 준비는 앱 전체의 변경 잠금을 올리지 않으며, 실제 데이터 복사·Compose 실행 중에는 변경 작업을 보호한다.

## 현재 공개 파일

공개 파일은 **0.1.16 미서명 개발판 · 백신 검사 미완료**다. 화면 내장 수정은 포함하지만, 위 프로젝트 버튼·행별 대기열·Compose 설정 이전·추가 시간 초과 수정은 후속 소스 변경이며 기존 공개 EXE·ZIP에 반영됐다고 주장하지 않는다.

| 기록 | 확인한 범위 |
| --- | --- |
| [0.1.16 공개 기록](https://github.com/seo-gali/dockslate/blob/main/docs/results/public-distribution-0.1.16.json) | 공개 EXE·ZIP·고지 ZIP·체크섬 4개의 다운로드 SHA-256, 홈페이지·정적 자산·기존 고지 주소 26개 |
| [0.1.16 제작·화면 검사](https://github.com/seo-gali/dockslate/blob/main/docs/results/release-0.1.16.json) | 해당 바이너리의 패키지 대조, 내장 화면 2개, 당시 Node·Rust·CLI·CI 검사 |
| [백신 검사·공개 승인](https://github.com/seo-gali/dockslate/blob/main/docs/results/virustotal-0.1.16.json) | reCAPTCHA로 새 검사가 미완료인 상태에서 정확한 파일 4개만 개발판 공개 승인. 탐지 수는 미확인 |

0.1.15와 그 이전 기록의 성공·탐지·시간 초과·개인 PC 경로는 당시 버전과 해시의 사실이다. 현재 소스의 실행 결과로 합산하지 않는다. 과거 요청과 검증은 [문서 안내](https://github.com/seo-gali/dockslate/blob/main/docs/README.md)의 버전별 기록에서 확인한다.

## 남은 실제 확인

- 문제가 발생한 다른 Windows PC에서의 재현·성능과 `Docker Desktop · container create` 종료 1의 실제 원인.
- 새 프로젝트 순차 실행과 설정 전용 Compose 이전의 실제 사용자 프로젝트·두 엔진 검증.
- 전체 새 설치·업그레이드·제거·재부팅·롤백과 정식 코드 서명.
- 공개 0.1.16의 백신 검사 완료와 후속 소스의 새 EXE·ZIP 제작·검사·배포.

이번 후속 수정의 테스트 결과는 [시간 초과 수정 검사](https://github.com/seo-gali/dockslate/blob/main/docs/results/migration-timeout.json)의 후속 항목에 기록한다. 이전 버전의 테스트 수치로 대신하지 않는다.
