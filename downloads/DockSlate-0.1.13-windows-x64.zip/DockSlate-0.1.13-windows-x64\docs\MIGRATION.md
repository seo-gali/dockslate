# Docker Desktop에서 가져오기

설정의 **데이터 가져오기**에서 실행 중인 Docker Desktop Linux 엔진을 조회하고 이미지·컨테이너·local 볼륨을 선택한다. 전체 선택과 종류별 선택을 제공한다. DockSlate 엔진도 먼저 시작해야 한다. 기본 가져오기는 0.1.11부터 제공한다. 자동 중지·실행 상태 유지·폴더 복사는 0.1.13 제작본에 포함한다. 현재 홈페이지 공개본 0.1.12에는 포함되지 않는다.

가져오기는 선택 기능이다. Docker Desktop이 없는 PC에서는 DockSlate 엔진을 단독 설치해 사용하며 가져오기를 할 필요가 없다. DockSlate 엔진이 이미 설치돼 있으면 소유권을 확인해 기존 엔진·데이터를 사용한다. Docker Desktop이 있는 PC에서는 이를 이전 원본으로 연결한다. Docker Desktop 엔진을 DockSlate의 상시 관리 대상으로 선택하는 모드는 제공하지 않는다.

## 복사와 보존

- 검사 → 대상·영향 확인 → 승인 → 복사 순서다. 선택한 컨테이너의 이미지·볼륨·bridge 네트워크도 함께 검사한다. 이전 이력 라벨과 설정이 같은 기존 네트워크는 승인창에 표시해 재사용한다. 나머지 이름·태그 충돌은 덮어쓰지 않고 차단한다.
- 기본 선택인 **실행 중인 원본 정상 중지**는 승인창에 표시한 선택 컨테이너만 중지한다. 같은 볼륨·폴더를 쓰는 다른 실행 컨테이너도 선택해야 한다. 강제 종료 없이 정상 종료를 기다리며 제한 시간 내 종료되지 않으면 복사를 중단한다. 원본 컨테이너·데이터는 삭제하지 않는다. 이전 중에는 원본과 대상 데이터를 변경하지 않는다.
- 이미지와 컨테이너 쓰기 계층, 환경 설정, 포트, 볼륨 연결을 복사한다. 컨테이너 쓰기 계층은 export/import로 보존하므로 복사본 이미지의 원래 레이어 이력은 유지되지 않는다. 환경 변수에 든 비밀번호도 새 컨테이너로 전달되며 화면·진행 로그에는 값을 표시하지 않는다.
- 볼륨은 실행하지 않는 임시 컨테이너에 연결해 tar 스트림으로 복사한다. 원본 볼륨은 읽기 전용·nocopy다. 임시 컨테이너만 정리하며 원본 볼륨·컨테이너·이미지는 제거하지 않는다. 새 이미지를 외부에서 받거나 데이터를 외부로 전송하지 않는다.
- 기본 선택인 **원래 실행 상태 유지**는 모든 복사본을 만든 뒤 원래 실행 중이던 컨테이너만 DockSlate에서 시작한다. Compose 의존성 라벨이 있으면 선택한 서비스의 시작 순서를 맞춘다. 해제하면 복사본은 중지 상태다. 원본은 중지 상태로 보존한다. 시작 실패는 실패한 대상과 함께 보고하며 원본을 자동 재시작하지 않는다. 프로세스 시작 확인이 서비스의 정상 동작·건강 검사를 대신하지는 않는다. 양쪽 서비스의 동시 실행과 포트 충돌을 피하려면 결과를 확인한 뒤 한쪽만 시작한다.
- Windows·WSL·Linux bind 파일과 폴더는 읽기 전용 연결의 실행하지 않는 임시 컨테이너에서 읽어 새 local 볼륨으로 복사한다. 단일 파일도 볼륨 하위 경로로 연결해 컨테이너 안 경로·읽기 전용 여부·UID/GID·권한을 유지한다. 같거나 상위·하위인 원본 경로는 같은 복사본을 공유한다. 호스트의 원래 폴더와는 이후 동기화되지 않는다. Docker 소켓은 내용을 복사하지 않고 DockSlate 엔진 소켓으로 다시 연결하며 승인창에 표시한다.
- 중간 실패 시 이미 복사한 대상은 남겨 결과에 표시한다. 재실행으로 덮어쓰거나 일괄 롤백하지 않는다. tar는 공용 임시 폴더 대신 `%LOCALAPPDATA%\DockSlate\migration` 아래에 만들고 성공·실패 시 닫고 삭제한다. 파일당 64 GiB·복사당 1시간까지 지원하며 앱·PC의 강제 종료 후 남은 파일은 자동 삭제하지 않는다.

## 범위

Linux 컨테이너, 일반 bridge/none 네트워크, 옵션 없는 local 볼륨과 파일·폴더 bind 복사를 지원한다. 특권·장치·host/container 네트워크·고정 IP·Swarm 설정, 기본 private 이외의 bind propagation은 자동 이전하지 않고 사유를 표시한다. Compose 프로젝트 파일·Docker 로그인 정보·Kubernetes·빌드 캐시·로그·메모리·tmpfs 내용은 복사하지 않는다. Compose 라벨은 유지하지만 기존 프로젝트를 편집·재배포하는 기능은 아니다. 이름이 충돌하는 기존 복사본은 덮어쓰지 않으며 실패 후 남은 복사본의 재사용은 별도 검사 대상이다.

Docker Desktop 제거는 별도 사용자 작업이다. 모든 복사본의 정상 동작과 데이터를 확인하기 전에는 제거하지 않는다. [Docker 제거 안내](https://docs.docker.com/desktop/uninstall/)는 제거 시 기존 데이터를 잃을 수 있음을 설명한다. [export](https://docs.docker.com/reference/cli/docker/container/export/)는 볼륨 데이터를 포함하지 않으므로 볼륨을 별도로 복사하며, [cp](https://docs.docker.com/reference/cli/docker/container/cp/)의 tar 스트림·archive 모드로 UID/GID를 전달한다.

## 검증 기준

원본·대상 엔진 ID 구분, 승인 만료·변경 후 재검사, 이름·태그 충돌, 실행 중 볼륨 참조, 미지원 설정 거절, 환경 변수 비노출, 큰 tar의 파일 스트리밍, 임시 컨테이너 정리, 실패 후 부분 결과를 검사한다. fixture 검사와 실제 Docker Desktop 데이터 이전 검사는 구분한다. 사용자 데이터의 이전·삭제는 개발 검증에 포함하지 않는다.

후속 소스: `npm run check`의 Node 17개, Rust 보안 28개, 실제 React 컴포넌트의 격리 UI 검사 6개와 프런트엔드 빌드·Rust check가 통과했다. UI 검사는 명시적인 메모리 내 백엔드 fixture를 사용하며 실제 엔진 동작을 검증한 것으로 합산하지 않는다. 승인한 `scripts/verify-migration-bind.mjs`는 임시 볼륨 2개·컨테이너 4개와 sleep 프로세스만 사용해 실제 정상 종료·폴더/단일 파일 복사·UID/GID/권한·읽기 전용·정리를 검사했다(4개 통과). 최초 fixture는 PostgreSQL 이미지의 기본 SIGINT와 TERM 핸들러가 달라 종료 코드가 예상과 달랐고, 시험용 컨테이너에 SIGTERM을 명시한 뒤 통과했다. 기존 컨테이너·이미지·볼륨 목록과 상태가 같고 정리 오류가 없음을 확인했다. 이 검사는 같은 소유 엔진에서 전송 기본 동작을 확인한 것으로 실제 Docker Desktop 두 엔진의 전체 이전을 대신하지 않는다. [검사 기록](https://github.com/seo-gali/dockslate/blob/main/docs/results/desktop-migration.json)의 `followup` 항목에 범위를 구분한다.

[초기 검사 기록](https://github.com/seo-gali/dockslate/blob/main/docs/results/desktop-migration.json): Node 16개·Rust 18개·PATH 11개·Windows 프로세스 7개와 한국어·영어 화면을 검사했다. 승인된 소유 엔진에서 임시 볼륨 2개·실행하지 않는 컨테이너 3개로 바이너리 내용·UID/GID·권한 왕복 복사, 읽기 전용 쓰기 거절, 익명 볼륨 미생성을 확인하고 정리했다. 기존 목록·상태는 복원됐다. [0.1.11 제작·검사](https://github.com/seo-gali/dockslate/blob/main/docs/results/release-0.1.11.md)에서 설치판 제작과 공개 파일 대조를 확인했다. 이 PC에는 Docker Desktop이 없어 실제 두 엔진 사이의 전체 이전과 전체 설치·제거는 미검증이다. [설치 완료 검사 후속 수정](https://github.com/seo-gali/dockslate/blob/main/docs/results/windows-cli-contract.md#엔진-연결)은 별도 기록한다.
